package com.example.foodgeo_partner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
